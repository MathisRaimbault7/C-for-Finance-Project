#include "AsianCallOption.h"
#include "AsianOption.h"
#include <iostream>
#include <cmath>
#include <vector>


AsianCallOption::AsianCallOption(std::vector<double> vect, double strike) : _strike(strike), AsianOption(vect) {}

double AsianCallOption::getStrike() const
{
	return _strike;
}

double AsianCallOption::payoff(double meanprice) const {
	return (meanprice >= getStrike()) ? (meanprice - getStrike()) : 0.0; // returns the average price over the period minus strike if difference is positive else it returns 0
}
