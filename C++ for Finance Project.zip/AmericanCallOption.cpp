#include "AmericanCallOption.h"
#include <algorithm>

AmericanCallOption::AmericanCallOption(double expiry, double strike)
    : AmericanOption(expiry), _strike(strike) {}


double AmericanCallOption::payoff(double stockPrice) const {
    return std::max(stockPrice - _strike, 0.0); // Payoff for a call option
}
