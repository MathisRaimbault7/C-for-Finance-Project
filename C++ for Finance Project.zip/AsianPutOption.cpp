#include "AsianPutOption.h"
#include "AsianOption.h"
#include <iostream>
#include <cmath>
#include <vector>

AsianPutOption::AsianPutOption(std::vector<double> tk, double strike) : _strike(strike), AsianOption(tk) {}

double AsianPutOption::getStrike() const
{
	return _strike;
}

double AsianPutOption::payoff(double meanprice) const {
	return (meanprice <= getStrike()) ? (getStrike() - meanprice) : 0.0;// returns average price minus strike if difference negative else returns 0
}

