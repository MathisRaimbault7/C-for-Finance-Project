#include "EuropeanOption.h"

EuropeanOption::EuropeanOption(double expiry) : Option(expiry) {}