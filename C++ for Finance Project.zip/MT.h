#include <iostream>
#include <random>
#pragma once

class MT {
    private:
        static std::mt19937 mt_engine;
        static std::uniform_real_distribution<double> unif_dist;
        static std::normal_distribution<double> norm_dist;

        MT();
    public:
        // Delete copy constructor and assignment operator
        MT(const MT&) = delete;
        MT& operator=(const MT&) = delete;
    
        static double rand_unif();
        static double rand_norm();
        static std::mt19937& GetMtEngine();
};