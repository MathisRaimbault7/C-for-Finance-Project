﻿#include "BlackScholesMCPricer.h"
#include <iostream>
#include <numeric>

BlackScholesMCPricer::BlackScholesMCPricer(Option* _option, double initial_price, double interest_rate, double _volatility) : option(_option),initial_price(initial_price),interest_rate(interest_rate),volatility(_volatility),current_estimation(initial_price){

	//different options

	if (dynamic_cast<AsianCallOption*>(option))
	{
		callOption = dynamic_cast<AsianCallOption*>(option);
		putOption = nullptr;
	}
	else if (dynamic_cast<AsianPutOption*>(option))
	{
		putOption = dynamic_cast<AsianPutOption*>(option);
		callOption = nullptr;
	}else if (dynamic_cast<VanillaOption*>(option))
	{
		vanillaOption = dynamic_cast<VanillaOption*>(option);
		callOption = nullptr;
	}else if (dynamic_cast<DigitalOption*>(option))
	{
		digitalOption = dynamic_cast<DigitalOption*>(option);
		callOption = nullptr;
	}
}

int BlackScholesMCPricer::getNbPaths() const{
	return nbPaths_generated;
}

void BlackScholesMCPricer::generate(int nb_paths) {
	if (dynamic_cast<AsianCallOption*>(callOption)) {
		std::vector<double> time = callOption->getTimeSteps();
		double estimation = 0;
		sum_payoffs = 0;
		for (int it = 0; it < nb_paths; it++) {

			std::vector<double> S;
			double St = 0;
			St = initial_price * exp((interest_rate - (volatility * volatility) / 2) * time[0] + volatility * sqrt(time[0])*MT::rand_norm());
			S.push_back(St);
			for (int i = 1; i < time.size(); i++) {
				St = St * exp((interest_rate - (volatility * volatility) / 2) * (time[i] - time[i - 1]) + volatility * sqrt(time[i] - time[i - 1]) * MT::rand_norm());
				S.push_back(St);

			}
			estimation = callOption->payoffPath(S);
			sum_payoffs = sum_payoffs + estimation;
			sum_squared_payoffs = sum_squared_payoffs + (estimation * estimation);
			
		}
		current_estimation = current_estimation * nbPaths_generated;
		nbPaths_generated += nb_paths;
		current_estimation = (current_estimation + sum_payoffs) / nbPaths_generated;
	}else if (dynamic_cast<AsianPutOption*>(putOption)) {
		std::vector<double> time = putOption->getTimeSteps();
		double estimation = 0;
		sum_payoffs = 0;
		for (int it = 0; it < nb_paths; it++) {

			std::vector<double> S;
			double St = 0;
			St = initial_price * exp((interest_rate - (volatility * volatility) / 2) * time[0] + volatility * sqrt(time[0]) * MT::rand_norm());
			S.push_back(St);
			for (int i = 1; i < time.size(); i++) {
				St = St * exp((interest_rate - (volatility * volatility) / 2) * (time[i] - time[i - 1]) + volatility * sqrt(time[i] - time[i - 1]) * MT::rand_norm());
				S.push_back(St);

			}
			estimation = putOption->payoffPath(S);
			sum_payoffs = sum_payoffs + estimation;
			sum_squared_payoffs = sum_squared_payoffs + (estimation * estimation);

		}
		current_estimation = current_estimation * nbPaths_generated;
		nbPaths_generated += nb_paths;
		current_estimation = (current_estimation + sum_payoffs) / nbPaths_generated;
	}
	else if (dynamic_cast<VanillaOption*>(option)){
		
		double time = vanillaOption->getExpiry();
		double estimation = 0;
		sum_payoffs = 0;
		for (int it = 0; it < nb_paths; it++) {


			double St = initial_price * exp((interest_rate - (volatility * volatility) / 2) * time + volatility * sqrt(time) * MT::rand_norm());

			estimation = vanillaOption->payoff(St);
			sum_payoffs = sum_payoffs + estimation;
			sum_squared_payoffs = sum_squared_payoffs + (estimation * estimation);

		}
		current_estimation = current_estimation * nbPaths_generated;
		nbPaths_generated += nb_paths;
		current_estimation = (current_estimation + sum_payoffs) / nbPaths_generated;
	}
	else {
		
		double time = digitalOption->getExpiry();
		double estimation = 0;
		sum_payoffs = 0;
		for (int it = 0; it < nb_paths; it++) {

			double St = initial_price * exp((interest_rate - (volatility * volatility) / 2) * time+ volatility * sqrt(time) * MT::rand_norm());

			estimation = digitalOption->payoff(St);
			sum_payoffs = sum_payoffs + estimation;
			sum_squared_payoffs = sum_squared_payoffs + (estimation * estimation);

		}
		current_estimation = current_estimation * nbPaths_generated;
		nbPaths_generated += nb_paths;
		current_estimation = (current_estimation + sum_payoffs) / nbPaths_generated;
	}
	
}

double BlackScholesMCPricer::operator()() const{
	return current_estimation;
}

std::vector <double > BlackScholesMCPricer::confidenceInterval() {
	std::vector<double> intervalle;
	double mean = sum_payoffs / nbPaths_generated;
	double var = (sum_squared_payoffs / nbPaths_generated) - (mean * mean);
	intervalle.push_back(mean - 1.96 * sqrt(var) / sqrt(nbPaths_generated));
	intervalle.push_back(mean + 1.96 * sqrt(var) / sqrt(nbPaths_generated));
	
	return intervalle;
}