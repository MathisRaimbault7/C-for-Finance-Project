#include "AmericanPutOption.h"
#include <algorithm>

AmericanPutOption::AmericanPutOption(double expiry, double strike)
    : AmericanOption(expiry), _strike(strike) {}


double AmericanPutOption::payoff(double stockPrice) const {
    return std::max(_strike - stockPrice, 0.0); // Payoff for a put option
}
