#include <iostream>
#include <vector>
#include "Option.h"
#include "DigitalOption.h"
#include "AsianCallOption.h"
#include "AsianPutOption.h"
#include "VanillaOption.h"
#include "MT.h"

class BlackScholesMCPricer
{
private:
    Option* option;
    double initial_price;
    double interest_rate;
    double volatility;
    int nbPaths_generated=0;
    double current_estimation;
    double sum_payoffs=0;
    double sum_squared_payoffs=0;

    DigitalOption* digitalOption;
    AsianCallOption* callOption;
    AsianPutOption* putOption;
    VanillaOption* vanillaOption;

public:
    BlackScholesMCPricer(Option* option, double initial_price, double interest_rate, double volatility);
    int getNbPaths() const;
    void generate(int nbPaths);
    double operator()() const;
    std::vector<double> confidenceInterval();


};